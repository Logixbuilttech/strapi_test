import Header from "@/components/header"
import Hero from "@/components/hero"
import WhatWeDo from "@/components/what-we-do"
import TheEdge from "@/components/the-edge"
import OurProcess from "@/components/our-process"
import WhoWeEmpower from "@/components/who-we-empower"
import CustomCta from "@/components/custom-cta"
import Footer from "@/components/footer"

import {
  navigationLinks,
  heroData,
  whatWeDoData,
  theEdgeData,
  ourProcessData,
  whoWeEmpowerData,
  ctaData,
  footerData,
} from "../lib/data.js"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header links={navigationLinks} />
      <main className="flex-grow">
        <Hero data={heroData} />
        <WhatWeDo data={whatWeDoData} />
        <TheEdge data={theEdgeData} />
        <OurProcess data={ourProcessData} />
        <WhoWeEmpower data={whoWeEmpowerData} />
        <CustomCta data={ctaData} />
      </main>
      <Footer data={footerData} />
    </div>
  )
}
