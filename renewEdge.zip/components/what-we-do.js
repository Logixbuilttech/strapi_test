import Image from "next/image"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

export default function WhatWeDo({ data }) {
  const { tag, title, subtitle, services } = data

  return (
    <section id="what-we-do" className="py-20 md:py-28 bg-[#1a2228]">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12 md:mb-16">
          <p className="text-sm font-bold text-[#4ade80] uppercase tracking-wider mb-2">{tag}</p>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">{title}</h2>
          <p className="text-gray-400 md:text-lg">{subtitle}</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 items-center">
          <div className="space-y-8">
            {services.slice(0, 3).map((service, index) => (
              <ServiceCard key={index} service={service} />
            ))}
          </div>
          <div className="hidden lg:block">
            <Image
              src="/placeholder.svg?width=500&height=700&text=Tech+Illustration"
              alt="Tech Illustration"
              width={500}
              height={700}
              className="rounded-lg mx-auto"
            />
          </div>
        </div>
        <div className="grid lg:grid-cols-2 gap-8 items-center mt-8">
          <div className="hidden lg:block">
            <Image
              src="/placeholder.svg?width=500&height=500&text=Consulting+Illustration"
              alt="Consulting Illustration"
              width={500}
              height={500}
              className="rounded-lg mx-auto"
            />
          </div>
          <div className="space-y-8">
            {services.slice(3).map((service, index) => (
              <ServiceCard key={index} service={service} />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

function ServiceCard({ service }) {
  const Icon = service.icon
  return (
    <div className="bg-[#252f38] p-6 rounded-lg border border-gray-700/50">
      <div className="flex items-start gap-4">
        <div className="bg-[#4ade80]/10 p-3 rounded-full">
          <Icon className="w-6 h-6 text-[#4ade80]" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-white mb-2">{service.title}</h3>
          <p className="text-gray-400 mb-4">{service.description}</p>
          <Link href="#" className="font-semibold text-[#4ade80] hover:text-green-300 inline-flex items-center gap-2">
            Discover More <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </div>
  )
}
